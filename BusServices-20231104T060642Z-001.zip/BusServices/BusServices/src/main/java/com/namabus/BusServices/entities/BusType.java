package com.namabus.BusServices.entities;

public enum BusType {
  LUXURY,DELUXE,EXPRESS,ORDINARY,SUPERLUXURY
}
