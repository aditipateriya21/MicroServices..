package com.namabus.BusServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
