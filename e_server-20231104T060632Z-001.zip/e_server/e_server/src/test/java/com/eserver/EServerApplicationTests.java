package com.eserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
